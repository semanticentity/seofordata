require('dotenv').config();
const fs = require('fs');
const axios = require('axios');

// KeywordIn is the query
const keywordIn = 'site:the.com';
const keyword = keywordIn.toLocaleLowerCase();
const keywordClean = keyword.replace(/\s/g, '-');

const endpoint = 'https://api.dataforseo.com/v3/serp/google/organic/live/advanced';

const options = {
    method: 'post',
    auth: {
        username: process.env.USERNAME,
        password: process.env.PASSWORD 
    },
    data: [
        {
            keyword: encodeURIComponent(keyword),
            language_code: 'en',
            location_code: 2480
        }
    ],
    headers: { content_type: 'application/json' }
};

async function httpRequest() {
    try { 
        const response = await axios(endpoint, options)
        // console.log(response);
        // console.log(response.data);
        // console.log(JSON.stringify(response.data));     
        fs.writeFileSync(keywordClean + '.json', JSON.stringify(response.data));
    } catch(error) { 
        console.log(error); 
    }
}
httpRequest();
